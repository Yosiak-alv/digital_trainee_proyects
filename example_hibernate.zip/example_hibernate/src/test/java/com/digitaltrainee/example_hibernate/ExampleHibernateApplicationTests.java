package com.digitaltrainee.example_hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
