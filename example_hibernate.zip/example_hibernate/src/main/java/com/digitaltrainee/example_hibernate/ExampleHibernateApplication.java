package com.digitaltrainee.example_hibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleHibernateApplication.class, args);
	}

}
