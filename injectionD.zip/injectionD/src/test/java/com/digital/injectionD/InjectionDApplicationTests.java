package com.digital.injectionD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InjectionDApplicationTests {

	@Test
	void contextLoads() {
	}

}
