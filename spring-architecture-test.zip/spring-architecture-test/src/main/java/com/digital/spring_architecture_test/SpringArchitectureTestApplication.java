package com.digital.spring_architecture_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringArchitectureTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringArchitectureTestApplication.class, args);
	}

}
